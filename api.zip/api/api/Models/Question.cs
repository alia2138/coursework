﻿using System.Text.Json.Serialization;

namespace api.Models
{
    public class Question
    {
        public int Id { get; set; }

        public string Text { get; set; }

        public string Type { get; set; }

        public string OptionsJson { get; set; }

        public string CorrectAnswer { get; set; }

        public int LessonId { get; set; }

        [JsonIgnore]
        public Lesson Lesson { get; set; }

    }
}
